# bl0942

Измененный компонент для ESPHOME, совместимый с LibreTiny. Добавлено ожидание получения полного пакета данных. Оптимизировано время публикации показаний.

Modified component for ESPHOME, compatible with LibreTiny. Added waiting for the full data package to be received. Optimized the time of publication of sensors.
